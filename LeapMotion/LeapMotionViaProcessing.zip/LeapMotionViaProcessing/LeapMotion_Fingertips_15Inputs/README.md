This requires you to have the Leap SDK installed on your computer, and the de.voidplus.leapmotion library installed in Processing.
 